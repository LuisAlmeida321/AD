public class Rectangle {
    private Point topLeftPonit;
    private double height;
    private double width;

    public  Rectangle(){
        this.topLeftPonit = new Point();
        this.height = 0;
        this.width = 0;
    }
    public Rectangle(Point topLeftPonit, double height, double width) {
        this.topLeftPonit = topLeftPonit;
        this.height = height;
        this.width = width;
    }

    public Point getTopLeftPonit() {
        return topLeftPonit;
    }

    public void setTopLeftPonit(Point topLeftPonit) {
        this.topLeftPonit = topLeftPonit;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getArea (){
        return getHeight()*getWidth();
    }

    public double getPerimetro (){
        return (getHeight()*2)+(getWidth()*2);
    }

    public boolean isIn (Point p){
        Point bottomLeft = new Point(topLeftPonit.getX(), topLeftPonit.getY() - height);
        Point topRight = new Point(topLeftPonit.getX() + width, topLeftPonit.getY());
        Point bottomRight = new Point(topLeftPonit.getX() + width, topLeftPonit.getY() - height);
        if (p.getX() <= bottomRight.getX() && p.getY() <= bottomRight.getY() && p.getX() <= topLeftPonit.getX() && p.getY() <= topLeftPonit.getY()){
            return true;
        }else {
            return false;
        }
    }
}
