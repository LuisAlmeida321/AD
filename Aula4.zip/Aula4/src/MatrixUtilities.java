public class MatrixUtilities {
    public static void show(int[][] matrix){
        for (int i = 0; i < matrix.length; i++){
            for (int x = 0; x < matrix[i].length;x++){
                System.out.println(matrix[i][x]);
            }
            System.out.print("\n");
        }
    }
    public static boolean isMatrix(int[][] matrix){
        final int numColuna = matrix[0].length;
        for (int i = 0; i < matrix.length; i++) {
            if (numColuna != matrix[1].length) {
                return false;
            }
        }
        return true;
    }
    public static boolean isIdentity(int[][] matrix){
        for (int i = 0; i < matrix.length; i++){
            for (int x = 0; x < matrix[i].length;x++){
                if (i == x) {
                    if (matrix[i][x] != 1) {
                        return false;
                    }
                }
                else {
                    if(matrix[i][x] != 0){
                        return false;
                    }
                }
            }
        }
        return true;
    }
    public static int[][] multiplyBy(int[][] matrix, int multiply){
        for (int i = 0; i < matrix.length; i++){
            for (int x = 0; x < matrix[i].length;x++){
                matrix[i][x] *= multiply;
            }
        }
        return matrix;
    }
    public static boolean areCompatibleForSum(int[][] matrix, int[][] matrix2){
        if (matrix.length != matrix2.length){
            return false;
        }
        else {
            for (int i = 0; i < matrix.length; i++){
                if (matrix[i].length != matrix2[i].length){
                    return false;
                }
            }
        }
        return true;
    }
    public static int[][] sumOf(int[][] matrix, int[][] matrix2){
        if (areCompatibleForSum(matrix, matrix2) == true){
            for (int i = 0; i <matrix.length; i++){

            }
        }
    }
}

