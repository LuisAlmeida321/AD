public class Main {
    public static void Main(String[] args){
        int[][] matrix = {
                {1,0},
                {0,1}
        };
        int[][] matrix2 = {
                {1,0},
                {0,1}
        };
        MatrixUtilities.show(matrix);
        System.out.println(MatrixUtilities.isMatrix(matrix));
        System.out.println(MatrixUtilities.isIdentity(matrix));
        MatrixUtilities.multiplyBy(matrix, 5);
        System.out.println(MatrixUtilities.areCompatibleForSum(matrix,matrix2));
    }
}
