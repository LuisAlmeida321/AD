public class CharacterDrawingUtilities {
    public static void drawElement (char element){
        System.out.print(element);
    }
    public static void drawNewLine (char element){
        System.out.println();
    }
    public static void drawHorizontalSegmentWith(char vezes, char element){
        for (int i = 0; i < vezes; i++){
            drawElement(element);

        }
    }
}
